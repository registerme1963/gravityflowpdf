
<html>
<head>
</head>
<body bgcolor=#FFFFFF text=#001C66>

<h2>mPDF Font Utility scripts for Version 5.0</h2>
<p>
<a href="font_dump.php">Dump all characters from a font (font_dump.php)</a> 
</p>
<p>
<a href="font_names.php">Show a list of all font names available (font_names.php)</a> 
</p>
<p>
<a href="font_collections.php">Show fonts in Collections .ttc (font_collections.php)</a> 
</p>
<p>
<a href="font_coverage.php">Show coverage of characters from all fonts (font_coverage.php)</a> 
</p>
<p>
<a href="font_dump_OTL.php">Show OTL features from a font (font_dump_OTL.php)</a> 
</p>

<p>Edit the scripts to change the font folder if you wish - this is set by default to /ttfonts/</p>



</body>
</html>
